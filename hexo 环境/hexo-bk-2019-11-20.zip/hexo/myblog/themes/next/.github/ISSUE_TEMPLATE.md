
### Expected behavior (预期行为)


### Actual behavior (实际行为)


### Steps to reproduce the behavior (重现步骤)


### NexT Version, NexT Scheme

NexT Version:
  - [ ] Master
  - [ ] Latest Release
  - [ ] Old version -

NexT Scheme:
  - [ ] Muse
  - [ ] Mist
  - [ ] Pisces

### Other Information (Like Browser, System, Screenshots)


